package com.cg.mypaymentapp.repo;

import java.math.BigDecimal;
import java.util.Map;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;

public class WalletRepoImpl implements WalletRepo {

	Map<String, Customer> customerMap;
	 public WalletRepoImpl() {
		customerMap= DBStore.createCollection();
		customerMap.put("8686682006", new Customer("Sunny", "8686682006", new Wallet(BigDecimal.valueOf(5000))));
		customerMap.put("8328356335", new Customer("Sonu", "8328356335", new Wallet(BigDecimal.valueOf(10000))));
	}
	
	@Override
	public boolean save(Customer customer) {
		
		if(customer!=null){
		customerMap.put(customer.getMobileNo(), customer);
		return true;
		}
		
		return false;
	}
	@Override
	public Customer findOne(String mobileNo) {
		if(customerMap.containsKey(mobileNo)){
		Customer customer =customerMap.get(mobileNo);
		return customer;
		}
		
		return null;
	}
	
	
	
}
